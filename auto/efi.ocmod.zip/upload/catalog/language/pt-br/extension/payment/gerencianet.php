<?php
$_['button_confirm'] = 'Confirmar Pedido';
$_['message_error_gerencianet'] = 'Moeda não aceita. A Gerencianet processa apenas transações na moeda brasileira, o Real (código BRL)';